import json, sys
from pathlib import Path

p = Path(sys.argv[1])
data = json.loads(p.read_text(encoding="utf-8-sig"))

items = data.get("work_items") or []
done = [x for x in items if str((x or {}).get("status")) == "done"]
pending = [x for x in items if str((x or {}).get("status")) == "pending"]
inprog = [x for x in items if str((x or {}).get("status")) == "in_progress"]
blocked = [x for x in items if str((x or {}).get("status")) == "blocked"]

ordered = [x for x in items if str((x or {}).get("status")) in ("in_progress","pending")]
ordered = sorted(ordered, key=lambda x: (0 if str((x or {}).get("status")) == "in_progress" else 1, int((x or {}).get("priority") or 999)))

next_item = ordered[0] if ordered else {}

print(json.dumps({
  "roadmap_id": data.get("roadmap_id"),
  "counts": {
    "total": len(items),
    "done": len(done),
    "pending": len(pending),
    "in_progress": len(inprog),
    "blocked": len(blocked)
  },
  "next_item": {
    "id": next_item.get("id"),
    "title": next_item.get("title"),
    "status": next_item.get("status"),
    "priority": next_item.get("priority")
  }
}, ensure_ascii=False, indent=2))
