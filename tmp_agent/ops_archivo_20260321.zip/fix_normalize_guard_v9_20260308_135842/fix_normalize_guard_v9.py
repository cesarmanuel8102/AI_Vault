from pathlib import Path
import shutil, json

brain_py = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py")
backup   = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py.bak_fix_normalize_guard_v9_20260308_135842")
out_dir  = Path(r"C:\\AI_VAULT\\tmp_agent\\ops\\fix_normalize_guard_v9_20260308_135842")
out_dir.mkdir(parents=True, exist_ok=True)

src = brain_py.read_text(encoding="utf-8")
shutil.copy2(brain_py, backup)

start = "def _normalize_content_str(x):"
end   = "def _harden_plan_payload(plan: dict):"

i1 = src.find(start)
if i1 < 0:
    raise SystemExit("NO_START_NORMALIZE")

i2 = src.find(end, i1)
if i2 < 0:
    raise SystemExit("NO_END_HARDEN")

new_block = """def _normalize_content_str(x):
    if x is None:
        return None
    if not isinstance(x, str):
        x = str(x)

    compact = x.replace(" ", "")

    if (
        '"artifact_kind":"planner_schema_patch_apply_request"' in compact
        or '"artifact_kind":"planner_schema_patch_request"' in compact
        or '"expected_output_artifact":"planner_schema_patch_apply_request.json"' in compact
        or '"expected_output_artifact":"planner_schema_patch_request.json"' in compact
    ):
        return x

    if "__NOW_ISO_PLACEHOLDER__" in x:
        x = x.replace("__NOW_ISO_PLACEHOLDER__", _now_iso_utc_z())
    if "{{now_iso}}" in x:
        x = x.replace("{{now_iso}}", _now_iso_utc_z())

    x = x.replace("__LITERAL_BACKSLASH_N__", "\\n")
    x = x.replace("\\\\r\\\\n", "\\r\\n")
    x = x.replace("\\\\n", "\\n")
    return x

"""

src = src[:i1] + new_block + src[i2:]
brain_py.write_text(src, encoding="utf-8")

summary = {
    "ok": True,
    "brain_py": str(brain_py),
    "backup": str(backup),
    "out_dir": str(out_dir),
    "patched": "_normalize_content_str"
}
(out_dir / "01_patch_summary.json").write_text(
    json.dumps(summary, indent=2, ensure_ascii=False) + "\\n",
    encoding="utf-8"
)
print(json.dumps(summary, indent=2, ensure_ascii=False))
