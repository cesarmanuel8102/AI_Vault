from pathlib import Path
import shutil
import textwrap
import json

brain_py = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py")
backup   = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py.bak_apply_request_origin_v4_20260308_133440")
out_dir  = Path(r"C:\\AI_VAULT\\tmp_agent\\ops\\apply_request_origin_fix_v4_20260308_133440")

raw = brain_py.read_text(encoding="utf-8")
shutil.copy2(brain_py, backup)

def replace_block(src: str, start_marker: str, end_marker: str, replacement: str) -> str:
    i1 = src.find(start_marker)
    if i1 < 0:
        raise SystemExit(f"NO_START::{start_marker}")
    i2 = src.find(end_marker, i1)
    if i2 < 0:
        raise SystemExit(f"NO_END::{end_marker}")
    return src[:i1] + replacement + src[i2:]

helper = textwrap.dedent(r'''
def _is_apply_request_artifact(tool_name, tool_args):
    try:
        if tool_name not in ("write_file", "append_file"):
            return False

        args = tool_args if isinstance(tool_args, dict) else {}
        path = str(args.get("path") or "")

        vals = []
        for key in ("content", "raw_content", "text"):
            v = args.get(key)
            if v is None:
                continue
            vals.append(v if isinstance(v, str) else str(v))
        joined = "\n".join(vals)

        if (
            path.endswith("planner_schema_patch_apply_request.json")
            or path.endswith("planner_schema_patch_request.json")
        ):
            return True

        markers = (
            '"artifact_kind": "planner_schema_patch_apply_request"',
            '"artifact_kind": "planner_schema_patch_request"',
            '"expected_output_artifact": "planner_schema_patch_apply_request.json"',
            '"expected_output_artifact": "planner_schema_patch_request.json"',
        )
        return any(m in joined for m in markers)
    except Exception:
        return False

''').lstrip()

new_harden = textwrap.dedent(r'''
def _harden_plan_payload(plan: dict):
    errs = []
    if not isinstance(plan, dict):
        return plan, ["plan_not_object"]

    steps = plan.get("steps")
    if not isinstance(steps, list) or not steps:
        return plan, ["steps_empty_or_invalid"]

    for idx, st in enumerate(steps, start=1):
        if not isinstance(st, dict):
            errs.append(f"step_{idx}_not_object")
            continue

        tool = st.get("tool_name")
        args = st.get("tool_args") if isinstance(st.get("tool_args"), dict) else None
        if args is None:
            errs.append(f"step_{idx}_tool_args_missing_or_invalid")
            continue

        if tool in ("append_file", "write_file"):
            if "content" not in args and "text" in args:
                args["content"] = args.get("text")

            raw = args.get("content", None)
            if raw is None:
                errs.append(f"step_{idx}_content_null_for_{tool}")
                continue

            if _is_apply_request_artifact(tool, args):
                if not isinstance(raw, str):
                    raw = str(raw)
                args["content"] = raw
                args["text"] = raw
                args["raw_content"] = raw
                continue

            norm = _normalize_content_str(raw)
            if norm is None or (isinstance(norm, str) and len(norm) == 0):
                errs.append(f"step_{idx}_content_empty_after_normalize_for_{tool}")
                continue

            if norm != raw:
                args["raw_content"] = raw

            args["content"] = norm
            args["text"] = norm

    return plan, errs

''').lstrip()

new_safe = textwrap.dedent(r'''
def _p2_1_safe_tool_args(tool_name, tool_args):
    try:
        args = dict(tool_args) if isinstance(tool_args, dict) else {}

        if tool_name in ("write_file", "append_file"):
            raw = args.get("content", None)

            if raw is None and "text" in args:
                raw = args.get("text", None)

            if _is_apply_request_artifact(tool_name, args):
                if raw is None:
                    raw = args.get("raw_content", None)
                if raw is None:
                    return args
                if not isinstance(raw, str):
                    raw = str(raw)
                args["content"] = raw
                args["text"] = raw
                args["raw_content"] = raw
                return args

            if raw is None:
                raw = "__NOW_ISO_PLACEHOLDER__\n"

            if not isinstance(raw, str):
                raw = str(raw)

            norm = _normalize_content_str(raw)

            if norm is None or norm == "":
                norm = _now_iso_utc_z() + "\n"

            if norm != raw:
                args["raw_content"] = raw

            args["content"] = norm
            args["text"] = norm

        return args
    except Exception:
        return tool_args if isinstance(tool_args, dict) else {}

''').lstrip()

helper_start = "def _is_apply_request_artifact(tool_name, tool_args):"
harden_start = "def _harden_plan_payload(plan: dict):"
harden_end   = "# --- /HARDENING_PLAN_NORMALIZE_V3_CANONICAL"
safe_start   = "def _p2_1_safe_tool_args(tool_name, tool_args):"
safe_end     = "def _plan_steps(plan: dict):"

composite = helper + "\n" + new_harden + "\n"

if helper_start in raw:
    raw = replace_block(raw, helper_start, harden_end, composite)
else:
    raw = replace_block(raw, harden_start, harden_end, composite)

raw = replace_block(raw, safe_start, safe_end, new_safe + "\n" + safe_end)

brain_py.write_text(raw, encoding="utf-8")

summary = {
    "ok": True,
    "brain_py": str(brain_py),
    "backup": str(backup),
    "out_dir": str(out_dir),
}
(out_dir / "patch_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2, ensure_ascii=False))
