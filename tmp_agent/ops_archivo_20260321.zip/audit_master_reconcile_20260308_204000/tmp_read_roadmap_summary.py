import json
from pathlib import Path

p = Path(r"C:\AI_VAULT\tmp_agent\state\roadmap.json")
if not p.exists():
    print(json.dumps({"ok": False, "error": "roadmap.json missing"}, ensure_ascii=False, indent=2))
    raise SystemExit(0)

data = json.loads(p.read_text(encoding="utf-8-sig"))

items = []
def walk(node):
    if isinstance(node, dict):
        if "id" in node and "status" in node:
            items.append({
                "id": node.get("id"),
                "status": node.get("status"),
                "title": node.get("title"),
                "priority": node.get("priority"),
                "note": node.get("note")
            })
        for v in node.values():
            walk(v)
    elif isinstance(node, list):
        for x in node:
            walk(x)

walk(data)

done = [x for x in items if x.get("status") == "done"]
pending = [x for x in items if x.get("status") == "pending"]
inprog = [x for x in items if x.get("status") == "in_progress"]
blocked = [x for x in items if x.get("status") == "blocked"]

print(json.dumps({
    "ok": True,
    "roadmap_id": data.get("roadmap_id"),
    "status": data.get("status"),
    "updated_utc": data.get("updated_utc"),
    "counts": {
        "total": len(items),
        "done": len(done),
        "pending": len(pending),
        "in_progress": len(inprog),
        "blocked": len(blocked)
    },
    "items_sample": items[:20]
}, ensure_ascii=False, indent=2))
