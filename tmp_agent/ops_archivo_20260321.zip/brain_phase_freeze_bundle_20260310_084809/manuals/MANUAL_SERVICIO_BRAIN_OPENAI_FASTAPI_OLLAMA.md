# Manual de Servicio â€” Brain Lab / brain-openAI-FastAPI / Ollama

## Componentes
- Backend FastAPI: C:\AI_VAULT\00_identity\brain_server.py
- UI/Proxy: C:\AI_VAULT\00_identity\ui_proxy_server.py
- Runtime UI: C:\AI_VAULT\00_identity\ui_console_runtime_v1.py
- HTML UI: C:\AI_VAULT\00_identity\ui_console_conversational_v1.html

## Puertos
- 8010: backend / dashboard
- 8020: UI / proxy

## Estado persistente
RaÃ­z: C:\AI_VAULT\tmp_agent\state

## Artefactos clave
- roadmap.json
- brain_route_lock.json
- next_roadmap_discussion_required.json
- manuals_queue.json
- trust_score_operational.json
- historical_roadmap_reconciliation.json
- runtime_ui_audit_latest.json

## Gobernanza
El sistema separa:
- planner
- executor
- auditor
- gatekeeper

## Criterio de cierre
Una fase solo cierra cuando:
- roadmap sin pendientes ni in_progress,
- runtime visible,
- freeze bundle auditable,
- manual de usuario y de servicio.

## Freeze bundle actual
C:\AI_VAULT\tmp_agent\ops\brain_phase_freeze_bundle_20260310_084809