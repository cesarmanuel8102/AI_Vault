# Manual de Usuario â€” Brain Lab / brain-openAI-FastAPI / Ollama

## PropÃ³sito
Esta consola permite interactuar con el Brain en lenguaje natural, con approvals y trazabilidad operativa.

## URLs
- Consola conversacional: http://127.0.0.1:8020/ui
- Dashboard operativo: http://127.0.0.1:8010/ui/autobuild-dashboard-v3

## Uso bÃ¡sico
1. Entra a la consola.
2. Escribe una tarea en lenguaje natural.
3. Usa:
   - **Planificar**
   - **Planificar y ejecutar**
   - **Ejecutar plan actual**
4. Si la tarea requiere permisos, aprueba o rechaza en **Approvals**.

## Ejemplo
Crea un archivo en C:\AI_VAULT\tmp_agent\workspace\nota.txt con el texto hola brain

## QuÃ© verÃ¡s
- **MisiÃ³n**: objetivo actual
- **Plan**: pasos activos
- **Approvals**: acciones pendientes de permiso
- **Resumen operativo**: rutas Ãºtiles

## Rooms
Cada room separa el contexto. Usa rooms distintas para tareas distintas.

## Salud del sistema
Debe cargar:
- 8020 para la consola
- 8010 para dashboard y healthz

## Freeze bundle de esta fase
C:\AI_VAULT\tmp_agent\ops\brain_phase_freeze_bundle_20260310_084809