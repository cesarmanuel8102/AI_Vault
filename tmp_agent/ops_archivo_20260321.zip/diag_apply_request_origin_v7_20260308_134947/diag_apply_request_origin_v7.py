from pathlib import Path
import importlib.util
import json
import hashlib
import copy
import urllib.request

brain_py = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py")
brain_api = "http://127.0.0.1:8010"
out_dir = Path(r"C:\\AI_VAULT\\tmp_agent\\ops\\diag_apply_request_origin_v7_20260308_134947")
out_dir.mkdir(parents=True, exist_ok=True)

def sha256_text(s):
    if s is None:
        return None
    if not isinstance(s, str):
        s = str(s)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def write_text(name, value):
    p = out_dir / name
    if value is None:
        p.write_text("", encoding="utf-8")
    else:
        if not isinstance(value, str):
            value = str(value)
        p.write_text(value, encoding="utf-8", newline="\n")
    return str(p)

spec = importlib.util.spec_from_file_location("brain_server_diag_v7", brain_py)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

rid = "diag_apply_request_origin_v7"
artifact_json = r'''{
  "room_id": "__RID__",
  "phase": "P2_PLANNER_HARDENING_SCHEMA_NORMALIZATION",
  "artifact_kind": "planner_schema_patch_apply_request",
  "target_files": [
    "C:\\AI_VAULT\\00_identity\\brain_server.py"
  ],
  "ops": [
    {
      "id": "PATCH_NORMALIZE_CONTENT_FN",
      "file": "C:\\AI_VAULT\\00_identity\\brain_server.py",
      "anchor_start": "def _normalize_content_str(x):",
      "anchor_end": "def _harden_plan_payload(plan: dict):",
      "replace_mode": "between_anchors",
      "new_block": "def _normalize_content_str(x):\\n    if x is None:\\n        return None\\n    if \\"__NOW_ISO_PLACEHOLDER__\\" in x:\\n        x = x.replace(\\"__NOW_ISO_PLACEHOLDER__\\", _now_iso_utc_z())\\n    x = x.replace(\\"__LITERAL_BACKSLASH_N__\\", \\"\\\\n\\")\\n"
    }
  ],
  "deliverable_contract": {
    "expected_output_artifact": "planner_schema_patch_apply_request.json"
  }
}'''.replace("__RID__", rid)

tool_args = {
    "path": fr"C:\AI_VAULT\tmp_agent\state\rooms\{rid}\planner_schema_patch_apply_request.json",
    "content": artifact_json
}

module_diag = {}
module_diag["helper_exists"] = hasattr(mod, "_is_apply_request_artifact")
module_diag["safe_exists"] = hasattr(mod, "_p2_1_safe_tool_args")
module_diag["harden_exists"] = hasattr(mod, "_harden_plan_payload")

helper_result = None
if module_diag["helper_exists"]:
    helper_result = mod._is_apply_request_artifact("write_file", copy.deepcopy(tool_args))
module_diag["helper_result"] = helper_result

safe_out = None
if module_diag["safe_exists"]:
    safe_out = mod._p2_1_safe_tool_args("write_file", copy.deepcopy(tool_args))

safe_content = safe_out.get("content") if isinstance(safe_out, dict) else None
safe_raw = safe_out.get("raw_content") if isinstance(safe_out, dict) else None

module_diag["safe_content_exact"] = (safe_content == artifact_json)
module_diag["safe_raw_exact"] = (safe_raw == artifact_json)
module_diag["safe_content_has_now_placeholder"] = ("__NOW_ISO_PLACEHOLDER__" in safe_content) if isinstance(safe_content, str) else False
module_diag["safe_content_has_literal_backslash_n"] = ("__LITERAL_BACKSLASH_N__" in safe_content) if isinstance(safe_content, str) else False
module_diag["safe_content_has_timestamp"] = False if not isinstance(safe_content, str) else bool(__import__("re").search(r'20\d\d-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z', safe_content))

plan = {
    "room_id": rid,
    "status": "active",
    "steps": [
        {
            "id": "RECOVERY_P2",
            "status": "todo",
            "tool_name": "write_file",
            "tool_args": copy.deepcopy(tool_args),
        }
    ]
}

hard_plan = None
hard_errs = None
if module_diag["harden_exists"]:
    hard_plan, hard_errs = mod._harden_plan_payload(copy.deepcopy(plan))

hard_step = None
if isinstance(hard_plan, dict):
    steps = hard_plan.get("steps")
    if isinstance(steps, list) and steps:
        hard_step = steps[0]

hard_args = hard_step.get("tool_args") if isinstance(hard_step, dict) else None
hard_content = hard_args.get("content") if isinstance(hard_args, dict) else None
hard_raw = hard_args.get("raw_content") if isinstance(hard_args, dict) else None

module_diag["hard_errs"] = hard_errs
module_diag["hard_content_exact"] = (hard_content == artifact_json)
module_diag["hard_raw_exact"] = (hard_raw == artifact_json)
module_diag["hard_content_has_now_placeholder"] = ("__NOW_ISO_PLACEHOLDER__" in hard_content) if isinstance(hard_content, str) else False
module_diag["hard_content_has_literal_backslash_n"] = ("__LITERAL_BACKSLASH_N__" in hard_content) if isinstance(hard_content, str) else False
module_diag["hard_content_has_timestamp"] = False if not isinstance(hard_content, str) else bool(__import__("re").search(r'20\d\d-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z', hard_content))

body = {
    "room_id": rid,
    "status": "active",
    "steps": [
        {
            "id": "RECOVERY_P2",
            "status": "todo",
            "tool_name": "write_file",
            "tool_args": copy.deepcopy(tool_args),
        }
    ]
}

data = json.dumps(body).encode("utf-8")
req = urllib.request.Request(
    brain_api + "/v1/agent/plan",
    data=data,
    headers={"Content-Type": "application/json"},
    method="POST",
)

with urllib.request.urlopen(req, timeout=30) as resp:
    live = json.loads(resp.read().decode("utf-8"))

live_step = None
try:
    for st in live["plan"]["steps"]:
        if st.get("id") == "RECOVERY_P2":
            live_step = st
            break
except Exception:
    live_step = None

live_args = live_step.get("tool_args") if isinstance(live_step, dict) else None
live_content = live_args.get("content") if isinstance(live_args, dict) else None
live_raw = live_args.get("raw_content") if isinstance(live_args, dict) else None

live_diag = {
    "response_ok": live.get("ok"),
    "live_content_exact": (live_content == artifact_json),
    "live_raw_exact": (live_raw == artifact_json),
    "live_content_has_now_placeholder": ("__NOW_ISO_PLACEHOLDER__" in live_content) if isinstance(live_content, str) else False,
    "live_content_has_literal_backslash_n": ("__LITERAL_BACKSLASH_N__" in live_content) if isinstance(live_content, str) else False,
    "live_content_has_timestamp": False if not isinstance(live_content, str) else bool(__import__("re").search(r'20\d\d-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z', live_content)),
    "live_path": live_args.get("path") if isinstance(live_args, dict) else None,
}

hashes = {
    "artifact_json": sha256_text(artifact_json),
    "safe_content": sha256_text(safe_content),
    "safe_raw": sha256_text(safe_raw),
    "hard_content": sha256_text(hard_content),
    "hard_raw": sha256_text(hard_raw),
    "live_content": sha256_text(live_content),
    "live_raw": sha256_text(live_raw),
}

write_text("01_artifact_json.txt", artifact_json)
write_text("02_safe_content.txt", safe_content)
write_text("03_safe_raw.txt", safe_raw)
write_text("04_hard_content.txt", hard_content)
write_text("05_hard_raw.txt", hard_raw)
write_text("06_live_content.txt", live_content)
write_text("07_live_raw.txt", live_raw)
(out_dir / "08_module_diag.json").write_text(json.dumps(module_diag, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
(out_dir / "09_live_response.json").write_text(json.dumps(live, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

summary = {
    "ok": True,
    "brain_py": str(brain_py),
    "out_dir": str(out_dir),
    "module_diag": module_diag,
    "live_diag": live_diag,
    "hashes": hashes,
}
(out_dir / "99_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(str(out_dir / "99_summary.json"))
