from pathlib import Path
import shutil, json

brain_py = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py")
backup   = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py.bak_apply_request_origin_v6_20260308_134519")
out_dir  = Path(r"C:\\AI_VAULT\\tmp_agent\\ops\\apply_request_origin_fix_v6_20260308_134519")
out_dir.mkdir(parents=True, exist_ok=True)

src = brain_py.read_text(encoding="utf-8")
shutil.copy2(brain_py, backup)

helper = """def _is_apply_request_artifact(tool_name, tool_args):
    try:
        if tool_name not in ("write_file", "append_file"):
            return False

        args = tool_args if isinstance(tool_args, dict) else {}
        path = str(args.get("path") or "")

        vals = []
        for key in ("content", "raw_content", "text"):
            v = args.get(key)
            if v is None:
                continue
            vals.append(v if isinstance(v, str) else str(v))
        joined = "\\n".join(vals)

        if (
            path.endswith("planner_schema_patch_apply_request.json")
            or path.endswith("planner_schema_patch_request.json")
        ):
            return True

        markers = (
            '"artifact_kind": "planner_schema_patch_apply_request"',
            '"artifact_kind": "planner_schema_patch_request"',
            '"expected_output_artifact": "planner_schema_patch_apply_request.json"',
            '"expected_output_artifact": "planner_schema_patch_request.json"',
        )
        return any(m in joined for m in markers)
    except Exception:
        return False

"""

if "def _is_apply_request_artifact(tool_name, tool_args):" not in src:
    anchor = "def _harden_plan_payload(plan: dict):"
    i = src.find(anchor)
    if i < 0:
        raise SystemExit("NO_ANCHOR_FOR_HELPER")
    src = src[:i] + helper + src[i:]

old_block = """        tool_args = st.get("tool_args") if isinstance(st.get("tool_args"), dict) else (st.get("args") if isinstance(st.get("args"), dict) else {})
        tool_args = _p2_1_safe_tool_args(tool_name, tool_args)
"""

new_block = """        tool_args = st.get("tool_args") if isinstance(st.get("tool_args"), dict) else (st.get("args") if isinstance(st.get("args"), dict) else {})
        if _is_apply_request_artifact(tool_name, tool_args):
            _raw_apply = tool_args.get("content", None)
            if _raw_apply is None and "text" in tool_args:
                _raw_apply = tool_args.get("text", None)
            if _raw_apply is None and "raw_content" in tool_args:
                _raw_apply = tool_args.get("raw_content", None)
            if _raw_apply is not None:
                if not isinstance(_raw_apply, str):
                    _raw_apply = str(_raw_apply)
                tool_args["content"] = _raw_apply
                tool_args["text"] = _raw_apply
                tool_args["raw_content"] = _raw_apply
        else:
            tool_args = _p2_1_safe_tool_args(tool_name, tool_args)
"""

if old_block not in src:
    raise SystemExit("ROUTE_BLOCK_NOT_FOUND")

src = src.replace(old_block, new_block, 1)

brain_py.write_text(src, encoding="utf-8", newline="\n")

summary = {
    "ok": True,
    "brain_py": str(brain_py),
    "backup": str(backup),
    "out_dir": str(out_dir),
    "route_patch_applied": True,
    "helper_present": True
}
(out_dir / "01_patch_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2, ensure_ascii=False))
