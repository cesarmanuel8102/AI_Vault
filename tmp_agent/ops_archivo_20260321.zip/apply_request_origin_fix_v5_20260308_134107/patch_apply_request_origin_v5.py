from pathlib import Path
import shutil, json, re

brain_py = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py")
backup   = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py.bak_apply_request_origin_v5_20260308_134107")
out_dir  = Path(r"C:\\AI_VAULT\\tmp_agent\\ops\\apply_request_origin_fix_v5_20260308_134107")
out_dir.mkdir(parents=True, exist_ok=True)

src = brain_py.read_text(encoding="utf-8")
shutil.copy2(brain_py, backup)

helper_lines = [
    "def _is_apply_request_artifact(tool_name, tool_args):",
    "    try:",
    "        if tool_name not in (\"write_file\", \"append_file\"):",
    "            return False",
    "",
    "        args = tool_args if isinstance(tool_args, dict) else {}",
    "        path = str(args.get(\"path\") or \"\")",
    "",
    "        vals = []",
    "        for key in (\"content\", \"raw_content\", \"text\"):",
    "            v = args.get(key)",
    "            if v is None:",
    "                continue",
    "            vals.append(v if isinstance(v, str) else str(v))",
    "        joined = \"\\n\".join(vals)",
    "",
    "        if (",
    "            path.endswith(\"planner_schema_patch_apply_request.json\")",
    "            or path.endswith(\"planner_schema_patch_request.json\")",
    "        ):",
    "            return True",
    "",
    "        markers = (",
    "            '\"artifact_kind\": \"planner_schema_patch_apply_request\"',",
    "            '\"artifact_kind\": \"planner_schema_patch_request\"',",
    "            '\"expected_output_artifact\": \"planner_schema_patch_apply_request.json\"',",
    "            '\"expected_output_artifact\": \"planner_schema_patch_request.json\"',",
    "        )",
    "        return any(m in joined for m in markers)",
    "    except Exception:",
    "        return False",
]
helper = "\n".join(helper_lines) + "\n\n"

harden_lines = [
    "def _harden_plan_payload(plan: dict):",
    "    errs = []",
    "    if not isinstance(plan, dict):",
    "        return plan, [\"plan_not_object\"]",
    "",
    "    steps = plan.get(\"steps\")",
    "    if not isinstance(steps, list) or not steps:",
    "        return plan, [\"steps_empty_or_invalid\"]",
    "",
    "    for idx, st in enumerate(steps, start=1):",
    "        if not isinstance(st, dict):",
    "            errs.append(f\"step_{idx}_not_object\")",
    "            continue",
    "",
    "        tool = st.get(\"tool_name\")",
    "        args = st.get(\"tool_args\") if isinstance(st.get(\"tool_args\"), dict) else None",
    "        if args is None:",
    "            errs.append(f\"step_{idx}_tool_args_missing_or_invalid\")",
    "            continue",
    "",
    "        if tool in (\"append_file\", \"write_file\"):",
    "            if \"content\" not in args and \"text\" in args:",
    "                args[\"content\"] = args.get(\"text\")",
    "",
    "            raw = args.get(\"content\", None)",
    "            if raw is None:",
    "                errs.append(f\"step_{idx}_content_null_for_{tool}\")",
    "                continue",
    "",
    "            if _is_apply_request_artifact(tool, args):",
    "                if not isinstance(raw, str):",
    "                    raw = str(raw)",
    "                args[\"content\"] = raw",
    "                args[\"text\"] = raw",
    "                args[\"raw_content\"] = raw",
    "                continue",
    "",
    "            norm = _normalize_content_str(raw)",
    "            if norm is None or (isinstance(norm, str) and len(norm) == 0):",
    "                errs.append(f\"step_{idx}_content_empty_after_normalize_for_{tool}\")",
    "                continue",
    "",
    "            if norm != raw:",
    "                args[\"raw_content\"] = raw",
    "",
    "            args[\"content\"] = norm",
    "            args[\"text\"] = norm",
    "",
    "    return plan, errs",
]
new_harden = "\n".join(harden_lines) + "\n\n"

safe_lines = [
    "def _p2_1_safe_tool_args(tool_name, tool_args):",
    "    try:",
    "        args = dict(tool_args) if isinstance(tool_args, dict) else {}",
    "",
    "        if tool_name in (\"write_file\", \"append_file\"):",
    "            raw = args.get(\"content\", None)",
    "",
    "            if raw is None and \"text\" in args:",
    "                raw = args.get(\"text\", None)",
    "",
    "            if _is_apply_request_artifact(tool_name, args):",
    "                if raw is None:",
    "                    raw = args.get(\"raw_content\", None)",
    "                if raw is None:",
    "                    return args",
    "                if not isinstance(raw, str):",
    "                    raw = str(raw)",
    "                args[\"content\"] = raw",
    "                args[\"text\"] = raw",
    "                args[\"raw_content\"] = raw",
    "                return args",
    "",
    "            if raw is None:",
    "                raw = \"__NOW_ISO_PLACEHOLDER__\\n\"",
    "",
    "            if not isinstance(raw, str):",
    "                raw = str(raw)",
    "",
    "            norm = _normalize_content_str(raw)",
    "",
    "            if norm is None or norm == \"\":",
    "                norm = _now_iso_utc_z() + \"\\n\"",
    "",
    "            if norm != raw:",
    "                args[\"raw_content\"] = raw",
    "",
    "            args[\"content\"] = norm",
    "            args[\"text\"] = norm",
    "",
    "        return args",
    "    except Exception:",
    "        return tool_args if isinstance(tool_args, dict) else {}",
]
new_safe = "\n".join(safe_lines) + "\n"

pat_harden = re.compile(
    r'(?:def _is_apply_request_artifact\(tool_name, tool_args\):.*?\n\n)?def _harden_plan_payload\(plan: dict\):.*?(?=\n# --- /HARDENING_PLAN_NORMALIZE_V3_CANONICAL)',
    re.S
)
src, n1 = pat_harden.subn(helper + new_harden, src, count=1)
if n1 != 1:
    raise SystemExit("PATCH_HARDEN_FAILED")

pat_safe = re.compile(
    r'def _p2_1_safe_tool_args\(tool_name, tool_args\):.*?(?=\ndef _plan_steps\(plan: dict\):)',
    re.S
)
src, n2 = pat_safe.subn(new_safe, src, count=1)
if n2 != 1:
    raise SystemExit("PATCH_SAFE_FAILED")

brain_py.write_text(src, encoding="utf-8", newline="\n")

summary = {
    "ok": True,
    "brain_py": str(brain_py),
    "backup": str(backup),
    "out_dir": str(out_dir),
    "patches": {
        "harden": n1,
        "safe_tool_args": n2
    }
}
(out_dir / "01_patch_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2, ensure_ascii=False))
