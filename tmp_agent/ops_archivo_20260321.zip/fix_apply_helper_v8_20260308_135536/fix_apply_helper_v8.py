from pathlib import Path
import shutil
import json

brain_py = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py")
backup   = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py.bak_fix_apply_helper_v8_20260308_135536")
out_dir  = Path(r"C:\\AI_VAULT\\tmp_agent\\ops\\fix_apply_helper_v8_20260308_135536")
out_dir.mkdir(parents=True, exist_ok=True)

src = brain_py.read_text(encoding="utf-8")
shutil.copy2(brain_py, backup)

new_helper = """def _is_apply_request_artifact(tool_name, tool_args):
    try:
        if tool_name not in ("write_file", "append_file"):
            return False

        args = tool_args if isinstance(tool_args, dict) else {}
        path = str(args.get("path") or "").strip().lower()

        if (
            path.endswith("planner_schema_patch_apply_request.json")
            or path.endswith("planner_schema_patch_request.json")
        ):
            return True

        vals = []
        for key in ("content", "raw_content", "text"):
            v = args.get(key)
            if v is None:
                continue
            vals.append(v if isinstance(v, str) else str(v))

        joined = "\\n".join(vals)
        joined_compact = joined.replace(" ", "")

        markers = (
            '"artifact_kind":"planner_schema_patch_apply_request"',
            '"artifact_kind":"planner_schema_patch_request"',
            '"expected_output_artifact":"planner_schema_patch_apply_request.json"',
            '"expected_output_artifact":"planner_schema_patch_request.json"',
        )
        return any(m in joined_compact for m in markers)
    except Exception:
        return False

"""

start_helper = "def _is_apply_request_artifact(tool_name, tool_args):"
start_harden = "def _harden_plan_payload(plan: dict):"

if start_helper in src:
    i1 = src.find(start_helper)
    i2 = src.find(start_harden, i1)
    if i2 < 0:
        raise SystemExit("NO_HARDEN_AFTER_HELPER")
    src = src[:i1] + new_helper + src[i2:]
else:
    i = src.find(start_harden)
    if i < 0:
        raise SystemExit("NO_HARDEN_ANCHOR")
    src = src[:i] + new_helper + src[i:]

brain_py.write_text(src, encoding="utf-8", newline="\\n")

summary = {
    "ok": True,
    "brain_py": str(brain_py),
    "backup": str(backup),
    "out_dir": str(out_dir),
    "helper_replaced_or_inserted": True
}
(out_dir / "01_patch_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\\n", encoding="utf-8")
print(json.dumps(summary, indent=2, ensure_ascii=False))
