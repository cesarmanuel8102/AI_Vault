from pathlib import Path
import shutil, json, re

brain_py = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py")
backup   = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py.bak_fix_ab01_apply_request_canonical_20260308_161555")
out_dir  = Path(r"C:\\AI_VAULT\\tmp_agent\\ops\\fix_ab01_apply_request_canonical_20260308_161555")
out_dir.mkdir(parents=True, exist_ok=True)

src = brain_py.read_text(encoding="utf-8")
shutil.copy2(brain_py, backup)

helper_block = """def _is_apply_request_artifact(tool_name, tool_args):
    try:
        if tool_name not in ("write_file", "append_file"):
            return False

        args = tool_args if isinstance(tool_args, dict) else {}
        path = str(args.get("path") or "").strip().lower()

        if (
            path.endswith("planner_schema_patch_apply_request.json")
            or path.endswith("planner_schema_patch_request.json")
        ):
            return True

        vals = []
        for key in ("content", "raw_content", "text"):
            v = args.get(key)
            if v is None:
                continue
            vals.append(v if isinstance(v, str) else str(v))

        joined = "\\n".join(vals)
        compact = "".join(joined.split())

        markers = (
            '"artifact_kind":"planner_schema_patch_apply_request"',
            '"artifact_kind":"planner_schema_patch_request"',
            '"expected_output_artifact":"planner_schema_patch_apply_request.json"',
            '"expected_output_artifact":"planner_schema_patch_request.json"',
        )
        return any(m in compact for m in markers)
    except Exception:
        return False

def _preserve_apply_request_tool_args(tool_args):
    args = dict(tool_args) if isinstance(tool_args, dict) else {}

    raw = args.get("raw_content", None)
    if raw is None:
        raw = args.get("content", None)
    if raw is None:
        raw = args.get("text", None)
    if raw is None:
        raw = ""

    if not isinstance(raw, str):
        raw = str(raw)

    args["content"] = raw
    args["raw_content"] = raw
    args["text"] = raw
    return args

"""

def replace_helper_block(text: str):
    harden_anchor = "def _harden_plan_payload(plan: dict):"
    harden_idx = text.find(harden_anchor)
    if harden_idx < 0:
        raise SystemExit("NO_HARDEN_ANCHOR")

    helper_anchor = "def _is_apply_request_artifact(tool_name, tool_args):"
    helper_idx = text.find(helper_anchor)

    if 0 <= helper_idx < harden_idx:
        return text[:helper_idx] + helper_block + text[harden_idx:], True

    return text[:harden_idx] + helper_block + text[harden_idx:], False

def patch_safe_tool_args_guard(text: str):
    fn_anchor = "def _p2_1_safe_tool_args(tool_name, tool_args):"
    start = text.find(fn_anchor)
    if start < 0:
        raise SystemExit("NO_SAFE_TOOL_ARGS_FN")

    m_next = re.search(r'(?m)^def [A-Za-z_][A-Za-z0-9_]*\(', text[start + 1:])
    end = (start + 1 + m_next.start()) if m_next else len(text)

    block = text[start:end]
    if "_preserve_apply_request_tool_args(args)" in block:
        return text, False

    m_args = re.search(
        r'(?m)^(?P<i>[ \t]+)args = dict\(tool_args\) if isinstance\(tool_args, dict\) else \{\}\s*$',
        block
    )
    if not m_args:
        raise SystemExit("NO_ARGS_LINE_IN_SAFE_TOOL_ARGS")

    indent = m_args.group("i")
    injected = (
        m_args.group(0)
        + "\n"
        + f"{indent}if _is_apply_request_artifact(tool_name, args):\n"
        + f"{indent}    return _preserve_apply_request_tool_args(args)"
    )

    block2 = block[:m_args.start()] + injected + block[m_args.end():]
    return text[:start] + block2 + text[end:], True

src, helper_replaced = replace_helper_block(src)
src, safe_guard_applied = patch_safe_tool_args_guard(src)

brain_py.write_text(src, encoding="utf-8", newline="\n")

summary = {
    "ok": True,
    "brain_py": str(brain_py),
    "backup": str(backup),
    "out_dir": str(out_dir),
    "helper_replaced_or_inserted": True,
    "helper_replaced_existing_block": helper_replaced,
    "safe_guard_applied": safe_guard_applied,
}
(out_dir / "01_patch_summary.json").write_text(
    json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
    encoding="utf-8"
)
print(json.dumps(summary, indent=2, ensure_ascii=False))
