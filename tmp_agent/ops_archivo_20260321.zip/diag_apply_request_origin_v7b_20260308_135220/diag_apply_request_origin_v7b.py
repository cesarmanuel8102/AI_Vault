from pathlib import Path
import json
import hashlib
import copy
import re
import urllib.request

brain_py = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py")
brain_api = "http://127.0.0.1:8010"
out_dir = Path(r"C:\\AI_VAULT\\tmp_agent\\ops\\diag_apply_request_origin_v7b_20260308_135220")
out_dir.mkdir(parents=True, exist_ok=True)

src = brain_py.read_text(encoding="utf-8")

def sha256_text(s):
    if s is None:
        return None
    if not isinstance(s, str):
        s = str(s)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def write_text(name, value):
    p = out_dir / name
    if value is None:
        p.write_text("", encoding="utf-8")
    else:
        if not isinstance(value, str):
            value = str(value)
        p.write_text(value, encoding="utf-8", newline="\n")
    return str(p)

def extract_block(text, start_marker, end_marker=None):
    i1 = text.find(start_marker)
    if i1 < 0:
        return None
    if end_marker is None:
        return text[i1:]
    i2 = text.find(end_marker, i1 + len(start_marker))
    if i2 < 0:
        return text[i1:]
    return text[i1:i2]

normalize_src = extract_block(src, "def _normalize_content_str(x):", "def _harden_plan_payload(plan: dict):")
helper_src    = extract_block(src, "def _is_apply_request_artifact(tool_name, tool_args):", "def _harden_plan_payload(plan: dict):")
harden_src    = extract_block(src, "def _harden_plan_payload(plan: dict):", "# --- /HARDENING_PLAN_NORMALIZE_V3_CANONICAL")
safe_src      = extract_block(src, "def _p2_1_safe_tool_args(tool_name, tool_args):", "def _plan_steps(plan: dict):")

write_text("01_normalize_src.py.txt", normalize_src)
write_text("02_helper_src.py.txt", helper_src)
write_text("03_harden_src.py.txt", harden_src)
write_text("04_safe_src.py.txt", safe_src)

ns = {}
exec("""
def _now_iso_utc_z():
    return "2099-01-01T00:00:00Z"
""", ns)

if helper_src:
    exec(helper_src, ns)
else:
    exec("""
def _is_apply_request_artifact(tool_name, tool_args):
    return False
""", ns)

if normalize_src:
    exec(normalize_src, ns)
else:
    raise SystemExit("NO_NORMALIZE_SRC")

if harden_src:
    exec(harden_src, ns)
else:
    raise SystemExit("NO_HARDEN_SRC")

if safe_src:
    exec(safe_src, ns)
else:
    raise SystemExit("NO_SAFE_SRC")

rid = "diag_apply_request_origin_v7b"
artifact_json = r'''{
  "room_id": "__RID__",
  "phase": "P2_PLANNER_HARDENING_SCHEMA_NORMALIZATION",
  "artifact_kind": "planner_schema_patch_apply_request",
  "target_files": [
    "C:\\AI_VAULT\\00_identity\\brain_server.py"
  ],
  "ops": [
    {
      "id": "PATCH_NORMALIZE_CONTENT_FN",
      "file": "C:\\AI_VAULT\\00_identity\\brain_server.py",
      "anchor_start": "def _normalize_content_str(x):",
      "anchor_end": "def _harden_plan_payload(plan: dict):",
      "replace_mode": "between_anchors",
      "new_block": "def _normalize_content_str(x):\\n    if x is None:\\n        return None\\n    if \\"__NOW_ISO_PLACEHOLDER__\\" in x:\\n        x = x.replace(\\"__NOW_ISO_PLACEHOLDER__\\", _now_iso_utc_z())\\n    x = x.replace(\\"__LITERAL_BACKSLASH_N__\\", \\"\\\\n\\")\\n"
    }
  ],
  "deliverable_contract": {
    "expected_output_artifact": "planner_schema_patch_apply_request.json"
  }
}'''.replace("__RID__", rid)

tool_args = {
    "path": fr"C:\AI_VAULT\tmp_agent\state\rooms\{rid}\planner_schema_patch_apply_request.json",
    "content": artifact_json
}

helper_result = ns["_is_apply_request_artifact"]("write_file", copy.deepcopy(tool_args))

safe_out = ns["_p2_1_safe_tool_args"]("write_file", copy.deepcopy(tool_args))
safe_content = safe_out.get("content") if isinstance(safe_out, dict) else None
safe_raw = safe_out.get("raw_content") if isinstance(safe_out, dict) else None

plan = {
    "room_id": rid,
    "status": "active",
    "steps": [
        {
            "id": "RECOVERY_P2",
            "status": "todo",
            "tool_name": "write_file",
            "tool_args": copy.deepcopy(tool_args),
        }
    ]
}

hard_plan, hard_errs = ns["_harden_plan_payload"](copy.deepcopy(plan))
hard_step = hard_plan["steps"][0]
hard_args = hard_step.get("tool_args", {})
hard_content = hard_args.get("content")
hard_raw = hard_args.get("raw_content")

body = {
    "room_id": rid,
    "status": "active",
    "steps": [
        {
            "id": "RECOVERY_P2",
            "status": "todo",
            "tool_name": "write_file",
            "tool_args": copy.deepcopy(tool_args),
        }
    ]
}

data = json.dumps(body).encode("utf-8")
req = urllib.request.Request(
    brain_api + "/v1/agent/plan",
    data=data,
    headers={"Content-Type": "application/json"},
    method="POST",
)

with urllib.request.urlopen(req, timeout=30) as resp:
    live = json.loads(resp.read().decode("utf-8"))

live_step = None
for st in live["plan"]["steps"]:
    if st.get("id") == "RECOVERY_P2":
        live_step = st
        break

live_args = live_step.get("tool_args", {}) if isinstance(live_step, dict) else {}
live_content = live_args.get("content")
live_raw = live_args.get("raw_content")

def has_ts(x):
    return bool(re.search(r'20\d\d-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z', x or ""))

summary = {
    "ok": True,
    "brain_py": str(brain_py),
    "out_dir": str(out_dir),
    "helper_result": helper_result,

    "safe": {
        "content_exact": safe_content == artifact_json,
        "raw_exact": safe_raw == artifact_json,
        "has_now_placeholder": "__NOW_ISO_PLACEHOLDER__" in (safe_content or ""),
        "has_literal_backslash_n": "__LITERAL_BACKSLASH_N__" in (safe_content or ""),
        "has_timestamp": has_ts(safe_content),
        "content_sha256": sha256_text(safe_content),
        "raw_sha256": sha256_text(safe_raw),
    },

    "harden": {
        "errs": hard_errs,
        "content_exact": hard_content == artifact_json,
        "raw_exact": hard_raw == artifact_json,
        "has_now_placeholder": "__NOW_ISO_PLACEHOLDER__" in (hard_content or ""),
        "has_literal_backslash_n": "__LITERAL_BACKSLASH_N__" in (hard_content or ""),
        "has_timestamp": has_ts(hard_content),
        "content_sha256": sha256_text(hard_content),
        "raw_sha256": sha256_text(hard_raw),
    },

    "live": {
        "response_ok": live.get("ok"),
        "content_exact": live_content == artifact_json,
        "raw_exact": live_raw == artifact_json,
        "has_now_placeholder": "__NOW_ISO_PLACEHOLDER__" in (live_content or ""),
        "has_literal_backslash_n": "__LITERAL_BACKSLASH_N__" in (live_content or ""),
        "has_timestamp": has_ts(live_content),
        "content_sha256": sha256_text(live_content),
        "raw_sha256": sha256_text(live_raw),
    },

    "artifact_sha256": sha256_text(artifact_json),
}

write_text("05_artifact_json.txt", artifact_json)
write_text("06_safe_content.txt", safe_content)
write_text("07_safe_raw.txt", safe_raw)
write_text("08_harden_content.txt", hard_content)
write_text("09_harden_raw.txt", hard_raw)
write_text("10_live_content.txt", live_content)
write_text("11_live_raw.txt", live_raw)
(out_dir / "12_live_response.json").write_text(json.dumps(live, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
(out_dir / "99_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

print(str(out_dir / "99_summary.json"))
