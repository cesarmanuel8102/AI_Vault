from pathlib import Path
import shutil, json, re

brain_py = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py")
backup   = Path(r"C:\\AI_VAULT\\00_identity\\brain_server.py.bak_ab03_fastapi_autobuild_control_20260308_162514")
out_dir  = Path(r"C:\\AI_VAULT\\tmp_agent\\ops\\ab03_fastapi_autobuild_control_20260308_162514")
out_dir.mkdir(parents=True, exist_ok=True)

src = brain_py.read_text(encoding="utf-8")
shutil.copy2(brain_py, backup)

block = r'''
# AUTO_BUILD_FASTAPI_CONTROL_V1 BEGIN
def _autobuild_now_utc_z():
    try:
        return _now_iso_utc_z()
    except Exception:
        from datetime import datetime, timezone
        return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def _autobuild_norm_room_id(room_id):
    try:
        return _norm_room_id(room_id)
    except Exception:
        rid = str(room_id or "default").strip()
        return rid or "default"

def _autobuild_rooms_root():
    from pathlib import Path as _Path
    root = _Path(r"C:\AI_VAULT\tmp_agent\state\rooms")
    root.mkdir(parents=True, exist_ok=True)
    return root

def _autobuild_room_dir(room_id):
    d = _autobuild_rooms_root() / _autobuild_norm_room_id(room_id)
    d.mkdir(parents=True, exist_ok=True)
    return d

def _autobuild_state_path(room_id):
    return _autobuild_room_dir(room_id) / "autobuild_state.json"

def _autobuild_default_state(room_id):
    rid = _autobuild_norm_room_id(room_id)
    return {
        "ok": True,
        "room_id": rid,
        "status": "idle",
        "enabled": False,
        "runner_script": r"C:\AI_VAULT\tmp_agent\ops\autobuild_roadmap_runner_v1.ps1",
        "max_items_per_run": 1,
        "stop_on_error": True,
        "runs": 0,
        "last_run_utc": None,
        "last_summary_path": None,
        "last_summary": None,
        "last_exit_code": None,
        "last_stdout_tail": None,
        "last_stderr_tail": None,
        "updated_utc": _autobuild_now_utc_z(),
    }

def _autobuild_read_state(room_id):
    import json as _json
    p = _autobuild_state_path(room_id)
    base = _autobuild_default_state(room_id)
    if not p.exists():
        return base
    try:
        raw = _json.loads(p.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            base.update(raw)
    except Exception:
        pass
    base["room_id"] = _autobuild_norm_room_id(room_id)
    return base

def _autobuild_write_state(room_id, state):
    import json as _json
    p = _autobuild_state_path(room_id)
    data = dict(state) if isinstance(state, dict) else _autobuild_default_state(room_id)
    data["room_id"] = _autobuild_norm_room_id(room_id)
    data["updated_utc"] = _autobuild_now_utc_z()
    p.write_text(_json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return data

def _autobuild_to_bool(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    s = str(value).strip().lower()
    if s in ("1", "true", "yes", "y", "on"):
        return True
    if s in ("0", "false", "no", "n", "off"):
        return False
    return default

def _autobuild_find_latest_summary(new_only_names=None):
    from pathlib import Path as _Path
    import json as _json

    ops_root = _Path(r"C:\AI_VAULT\tmp_agent\ops")
    candidates = sorted(
        [p for p in ops_root.glob("autobuild_roadmap_runner_v1_*") if p.is_dir()],
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )
    if new_only_names:
        filtered = [p for p in candidates if p.name in new_only_names]
        if filtered:
            candidates = filtered

    for d in candidates:
        s = d / "99_summary.json"
        if s.exists():
            try:
                data = _json.loads(s.read_text(encoding="utf-8"))
            except Exception:
                data = None
            return {
                "summary_path": str(s),
                "summary": data,
                "run_dir": str(d),
            }

    return {
        "summary_path": None,
        "summary": None,
        "run_dir": None,
    }

def _autobuild_run_once_shell(room_id, max_items=1, stop_on_error=True, dry_run=False):
    from pathlib import Path as _Path
    import subprocess as _subprocess

    runner = _Path(r"C:\AI_VAULT\tmp_agent\ops\autobuild_roadmap_runner_v1.ps1")
    before = set()
    ops_root = _Path(r"C:\AI_VAULT\tmp_agent\ops")
    if ops_root.exists():
        before = {p.name for p in ops_root.glob("autobuild_roadmap_runner_v1_*") if p.is_dir()}

    if dry_run:
        latest = _autobuild_find_latest_summary()
        return {
            "ok": True,
            "dry_run": True,
            "room_id": _autobuild_norm_room_id(room_id),
            "runner_script": str(runner),
            "runner_exists": runner.exists(),
            "summary_path": latest.get("summary_path"),
            "summary": latest.get("summary"),
            "run_dir": latest.get("run_dir"),
            "exit_code": 0,
            "stdout_tail": "",
            "stderr_tail": "",
        }

    if not runner.exists():
        return {
            "ok": False,
            "dry_run": False,
            "room_id": _autobuild_norm_room_id(room_id),
            "runner_script": str(runner),
            "runner_exists": False,
            "summary_path": None,
            "summary": None,
            "run_dir": None,
            "exit_code": 9009,
            "stdout_tail": "",
            "stderr_tail": f"No existe runner: {runner}",
        }

    cmd = [
        "powershell",
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(runner),
        "-MaxItems",
        str(int(max_items or 1)),
    ]
    if stop_on_error:
        cmd.append("-StopOnError")

    cp = _subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace"
    )

    after = set()
    if ops_root.exists():
        after = {p.name for p in ops_root.glob("autobuild_roadmap_runner_v1_*") if p.is_dir()}

    new_names = sorted(list(after - before))
    latest = _autobuild_find_latest_summary(set(new_names) if new_names else None)

    return {
        "ok": cp.returncode == 0,
        "dry_run": False,
        "room_id": _autobuild_norm_room_id(room_id),
        "runner_script": str(runner),
        "runner_exists": True,
        "summary_path": latest.get("summary_path"),
        "summary": latest.get("summary"),
        "run_dir": latest.get("run_dir"),
        "exit_code": cp.returncode,
        "stdout_tail": (cp.stdout or "")[-4000:],
        "stderr_tail": (cp.stderr or "")[-4000:],
    }

@app.post("/v1/agent/autobuild/start")
async def agent_autobuild_start(payload: dict = None):
    payload = payload or {}
    room_id = _autobuild_norm_room_id(payload.get("room_id"))
    state = _autobuild_read_state(room_id)

    state["enabled"] = True
    state["status"] = "active"
    state["runner_script"] = str(payload.get("runner_script") or state.get("runner_script") or r"C:\AI_VAULT\tmp_agent\ops\autobuild_roadmap_runner_v1.ps1")
    state["max_items_per_run"] = int(payload.get("max_items_per_run") or state.get("max_items_per_run") or 1)
    state["stop_on_error"] = _autobuild_to_bool(payload.get("stop_on_error"), state.get("stop_on_error", True))
    state["started_utc"] = state.get("started_utc") or _autobuild_now_utc_z()

    state = _autobuild_write_state(room_id, state)
    return {
        "ok": True,
        "room_id": room_id,
        "state_path": str(_autobuild_state_path(room_id)),
        "state": state,
        "impl": "AUTO_BUILD_FASTAPI_CONTROL_V1",
    }

@app.get("/v1/agent/autobuild/status")
async def agent_autobuild_status(room_id: str = "default"):
    rid = _autobuild_norm_room_id(room_id)
    state = _autobuild_read_state(rid)
    return {
        "ok": True,
        "room_id": rid,
        "state_path": str(_autobuild_state_path(rid)),
        "state": state,
        "impl": "AUTO_BUILD_FASTAPI_CONTROL_V1",
    }

@app.post("/v1/agent/autobuild/run_once")
async def agent_autobuild_run_once(payload: dict = None):
    payload = payload or {}
    room_id = _autobuild_norm_room_id(payload.get("room_id"))
    state = _autobuild_read_state(room_id)

    if not state.get("enabled"):
        state["enabled"] = True
    state["status"] = "running"

    max_items = int(payload.get("max_items") or state.get("max_items_per_run") or 1)
    stop_on_error = _autobuild_to_bool(payload.get("stop_on_error"), state.get("stop_on_error", True))
    dry_run = _autobuild_to_bool(payload.get("dry_run"), False)

    result = _autobuild_run_once_shell(
        room_id=room_id,
        max_items=max_items,
        stop_on_error=stop_on_error,
        dry_run=dry_run,
    )

    state["runs"] = int(state.get("runs") or 0) + 1
    state["last_run_utc"] = _autobuild_now_utc_z()
    state["last_exit_code"] = result.get("exit_code")
    state["last_summary_path"] = result.get("summary_path")
    state["last_summary"] = result.get("summary")
    state["last_stdout_tail"] = result.get("stdout_tail")
    state["last_stderr_tail"] = result.get("stderr_tail")
    state["last_run_dir"] = result.get("run_dir")
    state["last_mode"] = ((result.get("summary") or {}).get("last_mode") if isinstance(result.get("summary"), dict) else None)

    if dry_run:
        state["status"] = "active"
    elif result.get("ok"):
        stop_reason = None
        if isinstance(result.get("summary"), dict):
            stop_reason = result["summary"].get("stop_reason")
        state["status"] = "idle" if stop_reason in ("roadmap_exhausted", "completed_requested_cycles") else "active"
    else:
        state["status"] = "error"

    state = _autobuild_write_state(room_id, state)

    return {
        "ok": bool(result.get("ok")),
        "room_id": room_id,
        "state_path": str(_autobuild_state_path(room_id)),
        "state": state,
        "result": result,
        "impl": "AUTO_BUILD_FASTAPI_CONTROL_V1",
    }
# AUTO_BUILD_FASTAPI_CONTROL_V1 END

'''

anchor = '@app.get("/v1/agent/healthz")'
idx = src.find(anchor)
if idx < 0:
    raise SystemExit("NO_HEALTHZ_ANCHOR")

marker_begin = "# AUTO_BUILD_FASTAPI_CONTROL_V1 BEGIN"
marker_end   = "# AUTO_BUILD_FASTAPI_CONTROL_V1 END"

if marker_begin in src and marker_end in src:
    p1 = src.find(marker_begin)
    p2 = src.find(marker_end, p1)
    if p1 < 0 or p2 < 0:
        raise SystemExit("BAD_EXISTING_AUTOBUILD_BLOCK")
    p2 = src.find("\n", p2)
    if p2 < 0:
        p2 = len(src)
    src = src[:p1] + block + src[p2:]
else:
    src = src[:idx] + block + "\n" + src[idx:]

brain_py.write_text(src, encoding="utf-8", newline="\n")

summary = {
    "ok": True,
    "brain_py": str(brain_py),
    "backup": str(backup),
    "out_dir": str(out_dir),
    "block_installed": True,
}
(out_dir / "01_patch_summary.json").write_text(
    json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
    encoding="utf-8"
)
print(json.dumps(summary, indent=2, ensure_ascii=False))
