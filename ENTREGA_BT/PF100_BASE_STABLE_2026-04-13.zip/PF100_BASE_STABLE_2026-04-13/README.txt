PF100 BASE STABLE (Monetizable)
Date: 2026-04-13

Current best robust candidate:
- Candidate: PF100_R1150_V1030_OPT
- STRESS_2020: +0.197%, DD 3.2%, dbr=0, tbr=0
- FULL_2022_2026Q1: +21.461%, DD 3.0%
- OOS_2025_2026Q1: +14.489%, DD 2.3%

Reference baseline:
- PF100_D7_SECOND_AGGR_BASELINE
- STRESS_2020: +0.146%, DD 3.2%, dbr=0, tbr=0
- FULL_2022_2026Q1: +20.94%, DD 2.9%
- OOS_2025_2026Q1: +14.092%, DD 2.1%

Important metric note:
- The runner's monthly_mean_pct counts only months with trades.
- For true calendar monthly pace (OOS 2025-01 to 2026-03, 15 months):
  - PF100_D7: ~0.883%/month compounded
  - PF100_R1150_V1030_OPT: ~0.906%/month compounded

What was tested in this cycle:
1) Block3 quality filter: improved STRESS/DD but cut OOS too much.
2) Block4 second-entry unlock: no OOS improvement.
3) Risk sweep and VIXY local sweep: small robust uplift found in R1150_V1030.

Production decision:
- Keep PF100 as monetizable base.
- Promote PF100_R1150_V1030_OPT as current top robust variant.
- Use block3/block4 as research-only branches.

Files:
- main.py
- params_pf100_d7_baseline.json
- params_pf100_r1150_v1030_opt.json
- mreq_* runners
- results/* latest backtest outputs
