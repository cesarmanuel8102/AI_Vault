PF100 QuantAnalyze Upload Bundle

Contenido para subir/analizar en QuantAnalyze:
- main.py
- params_pf100_d7_base.json
- summary_metrics.csv / summary_metrics.json
- exports/trades_STRESS_2020.csv
- exports/trades_FULL_2022_2026Q1.csv
- exports/trades_OOS_2025_2026Q1.csv
- exports/equity_STRESS_2020.csv
- exports/equity_FULL_2022_2026Q1.csv
- exports/equity_OOS_2025_2026Q1.csv

Backtests fuente (QC):
- STRESS_2020: 35da253994a1be91f3c280cb6a62516a
- FULL_2022_2026Q1: 811a366b44845e699a4349ea4b569178
- OOS_2025_2026Q1: bcfb8ae3d084a85220a50effaee63a24

Recomendación en QuantAnalyze:
1) Cargar los CSV de trades por escenario para breakdown de edge.
2) Cargar equity_* para curva y estabilidad temporal.
3) Usar params_pf100_d7_base.json como baseline de reproducibilidad.
