FAST PASS STAGE 2 CONSOLIDATION
Date: 2026-04-13

Decision summary:
- Tuning around PF100 family produced a stable speed floor at 154 calendar days (CH_2025), with no internal breaches.
- Best candidate remains PFPASS_B_R125 (and equivalent clones):
  pass=True, cal_days=154, tr_days=20, np=8.346%, dd=3.0%, dbr=0, tbr=0.

What was tested in this stage:
1) PF100 passspeed baseline + validate (2022/2023/2024/2025/stress)
2) Stage2: capacity/risk unlock
3) Stage3: turnover/timing/universe/gate variants
4) Stage4: high-risk escalation
5) Stage5: daily profit lock tuning
6) Stage6: static MLL proxy (MFFU-aligned floor check)
7) Alternate standalone pass_fast_main aggressive variants

Result:
- No candidate beat 154 days while keeping clean breach profile in the modeled constraints.
- High-risk variants increase PnL but usually introduce trailing breaches and/or no speed gain.

Practical interpretation:
- PF100 family is robust but speed-limited for challenge pass.
- Next improvement likely requires a genuinely different alpha for pass-fast,
  not additional local parameter tuning.

Verified rule references (MFFU, checked 2026-04-13):
- Traders Evaluation Simplified:
  https://help.myfundedfutures.com/en/articles/11802636-traders-evaluation-simplified
- Consistency Rule:
  https://help.myfundedfutures.com/en/articles/11994562-consistency-rule-at-my-funded-futures
- Flex Plan Path Forward:
  https://help.myfundedfutures.com/en/articles/13521620-flex-plan-the-path-forward
- News Trading Policy:
  https://help.myfundedfutures.com/en/articles/8230009-news-trading-policy
- Permitted Times to Trade:
  https://help.myfundedfutures.com/en/articles/9558251-permitted-times-to-trade
- Fair Play:
  https://help.myfundedfutures.com/en/articles/8444599-fair-play-and-prohibited-trading-practices

Recommended next stage:
- Build pass-fast V2 (separate engine) with explicit challenge objective:
  maximize speed-to-target under static MLL + 50% consistency + no prohibited news window execution.
