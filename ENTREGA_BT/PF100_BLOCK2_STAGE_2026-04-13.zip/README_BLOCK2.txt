PF100 Block2 Stage (Partial TP + Runner)

Resumen rápido:
- Referencia D7 sigue líder en OOS mean (~1.528% mensual).
- Variantes Block2 mantuvieron robustez (sin breaches en principales) pero no mejoraron retorno neto.
- partial_fills=0 en todos los casos: con el sizing actual, las entradas quedan en 1 contrato y no hay fraccionamiento real.
- trail_updates sí ocurrieron, pero tendieron a recortar algo de retorno en FULL/OOS.

Conclusión operativa:
- Mantener Block2 desactivado por defecto en producción PF100.
- Si se quiere que partial funcione de verdad, hay que rediseñar tamaño mínimo por entrada (>=2 contratos) o usar ejecución multi-lote explícita.

Archivos:
- main.py (incluye Block2 opcional via params)
- mreq_pf100_block2_grid.py
- pf100_block2_grid_results.json/txt
