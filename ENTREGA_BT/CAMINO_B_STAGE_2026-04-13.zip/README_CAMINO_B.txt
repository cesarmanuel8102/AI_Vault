CAMINO B - Estado actual (2026-04-13)

T1 (trend standalone, STRESS 2020):
- CB_T1_E_AGGR: +1.834%, DD 0.4%, dbr=0, tbr=0
- CB_T1_B: +1.306%, DD 0.1%, dbr=0, tbr=0

T2 (dual trend+MR):
- Trend stress quedó fuerte en pruebas iniciales.
- El switch de régimen aún requiere calibración para no degradar OOS.
- T2/T2B actuales no pasan criterio OOS objetivo.

Siguiente iteración sugerida:
1) Ajustar detector stress externo (señales y umbral).
2) Recalibrar bloque normal MR en T2 con baseline PF100-compatible.
3) Repetir STRESS->FULL->OOS con criterio de salida estricto.

Archivos:
- camino_b_main.py
- mreq_camino_b_t1.py
- mreq_camino_b_t2.py
- mreq_camino_b_t2b.py
- resultados *.json / *.txt
