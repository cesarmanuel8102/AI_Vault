PF100 BASE MONETIZABLE (snapshot 2026-04-13)

Proyecto base recomendado:
- Candidato: PF100_D7_SECOND_AGGR (equivalente E0/D8 en comportamiento)
- Clase/archivo: main.py (regime_mode=PF100)

Resultados de referencia:
- STRESS_2020: +0.146% | DD 3.2% | dbr=0 | tbr=0
- FULL_2022_2026Q1: +20.94% | DD 2.9% | monthly_mean=0.678%
- OOS_2025_2026Q1: +14.092% | DD 2.1% | monthly_mean=1.528%

IDs QC (últimos):
- STRESS_2020: 35da253994a1be91f3c280cb6a62516a
- FULL_2022_2026Q1: 811a366b44845e699a4349ea4b569178
- OOS_2025_2026Q1: bcfb8ae3d084a85220a50effaee63a24

Archivos en esta carpeta:
- main.py
- params_pf100_d7_base.json
- backtests/pf100_stage3_growth_results.json
- backtests/pf100_stage4_riskprobe_results.json

Uso recomendado:
1) Subir main.py al proyecto QC.
2) Cargar parámetros del JSON.
3) Validar en STRESS/FULL/OOS antes de live paper.

Frente de mejora (manteniendo robustez):
- Incremental only: microajustes en segunda entrada y sizing del core sin aumentar breaches.
- No cambiar arquitectura base PF100 para producción.
