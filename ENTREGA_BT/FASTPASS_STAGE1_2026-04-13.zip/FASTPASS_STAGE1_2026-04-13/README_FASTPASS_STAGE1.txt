FAST PASS STAGE 1
Date: 2026-04-13

Target prop firm selected: MyFundedFutures (MFFU) Flex 50k.
Rules verified from official help pages:
- Profit target: $3,000
- Maximum Loss Limit (EOD): $2,000
- Daily Loss Limit: None
- Consistency: 50% (evaluation only)
- Minimum trading days: 2
- Max contracts (eval 50k): 5 mini / 50 micro
- Sim-funded scale (50k Flex):
  $0-$1,499 => 2 mini / 20 micro
  $1,500-$1,999 => 3 mini / 30 micro
  $2,000+ => 5 mini / 50 micro
- Price Eval/Reset shown in article: Flex 50k = $107

Official sources (opened 2026-04-13):
1) https://help.myfundedfutures.com/en/articles/11802636-traders-evaluation-simplified
2) https://help.myfundedfutures.com/en/articles/11994562-consistency-rule-at-my-funded-futures
3) https://help.myfundedfutures.com/en/articles/13521620-flex-plan-the-path-forward
4) https://help.myfundedfutures.com/en/articles/8444599-fair-play-and-prohibited-trading-practices
5) https://help.myfundedfutures.com/en/articles/10771500-copy-trading-at-myfundedfutures

What was tested:
A) New standalone pass-fast strategy (pass_fast_main.py): no robust fast-pass found.
B) PF100-family pass-speed probe (recommended path):
   Best candidate for fast-pass without internal breaches:
   label: PFPASS_B_R125
   CH_2025: pass=True, pass_date=2025-07-29, cal_days=154, tr_days=20,
            np=8.346%, dd=3.0%, dbr=0, tbr=0

Cross-year validation for PFPASS_B_R125:
- 2022: no pass
- 2023: no pass
- 2024: pass (cal_days=189)
- 2025: pass (cal_days=154)
- 2020 stress: no pass; tbr=1

Interpretation:
- Fast-pass candidate works in recent regimes (2024-2025) with clean internal breaches.
- Not regime-invariant; keep PF100 stable model as monetizable/scaling engine.
- Use this candidate only for challenge pass acceleration lane.

Suggested next step:
- Stage 2 fast-pass iteration around PFPASS_B_R125
  objective: reduce pass speed to <=120 calendar days while keeping dbr=0/tbr=0.
