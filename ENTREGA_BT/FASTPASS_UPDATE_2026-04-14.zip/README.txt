FASTPASS UPDATE 2026-04-14

Resumen ejecutivo
- La rama nueva PF100_FASTPASS_V1 (archivo: pf100_fastpass_v1_main.py) NO logró edge utilizable en CH_2025.
- Mejor dirección práctica confirmada: PF100 en main.py con tuning de gate VIXY alrededor de 1.018-1.025.
- Mejor resultado limpio actual en challenge 2025: 145 días calendario a +6%, con dbr=0 y tbr=0.

Candidatos ganadores (equivalentes)
- S8_V1018
- S8_V1020
- S8_V1023
- S8_V1020_SMA10
- S8_V1021_MOM18

Métricas del grupo ganador
- pass6: True
- calendar_days_to_pass: 145
- net_profit_pct: 8.172
- daily_loss_breaches: 0
- trailing_breaches: 0

Archivos de resultados
- C:\AI_VAULT\tmp_agent\strategies\mean_reversion_eq\pf100_passspeed_stage8_vixy_fine_results.json
- C:\AI_VAULT\tmp_agent\strategies\mean_reversion_eq\pf100_passspeed_stage8_vixy_fine_results.txt
- C:\AI_VAULT\tmp_agent\strategies\mean_reversion_eq\pf100_passspeed_stage7_vixy_results.json
- C:\AI_VAULT\tmp_agent\strategies\mean_reversion_eq\pf100_passspeed_stage7_vixy_results.txt

Conclusión
- No se consiguió romper el piso de 145 días con robustez en esta iteración.
- El candidato operativo fast-pass más sólido sigue siendo PF100 (main.py) + gate VIXY optimizado.
