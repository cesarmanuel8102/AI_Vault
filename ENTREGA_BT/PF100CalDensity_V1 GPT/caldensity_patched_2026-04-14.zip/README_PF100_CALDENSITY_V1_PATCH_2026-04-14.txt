PF100_CALDENSITY_V1 — patch set 2026-04-14

Updated files:
- PF100_CALDENSITY_V1_main.py
- params_pf100_caldensity_v1_a.json
- params_pf100_caldensity_v1_b.json
- params_pf100_caldensity_v1_c.json
- params_pf100_caldensity_v1_d.json

Applied fixes:
1) second_entry_red_day_buffer_pct default in seeds changed from 0.0 to 0.003.
   This avoids blocking valid second entries from trivial mark-to-market noise.

2) PF100 stress trade count is now tracked per instrument.
   The stress entry cap no longer gets consumed globally by the first symbol that fires.

3) Second-entry breakout and PF100 stress breakout no longer use sec.Open.
   They now use a session_open_price captured from the first mapped minute bar seen that day.
   This removes reliance on potentially stale mapped security open values.

Recommended sweep set now:
- A: MES + MNQ
- B: MES + MNQ + M2K

Seeds C and D are still included for convenience, but they are lower priority because MYM is likely to add correlation more than diversification.
